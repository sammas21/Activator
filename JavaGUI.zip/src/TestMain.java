import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;


public class TestMain {
	
	
	
	
	public static void main(String[] args) {
		
		
		JLabel urlLabel, userLabel, passLabel, ctnLabel;
		JTextField ctnTextbox, userTextbox;
		JPasswordField passTextbox;
		final JTextField urlTextbox;
		JButton activateButton;
		JFrame f =  new JFrame();
		
		
		// url set
		
		urlLabel = new  JLabel("URL :");
		urlLabel.setBounds(10, 10, 70, 20);
		
		urlTextbox = new JTextField();
		urlTextbox.setBounds(80, 10, 300, 20);
		
		
		//user name set
		
		userLabel = new  JLabel("Username:");
		userLabel.setBounds(10, 35, 70, 20);
		
		userTextbox = new JTextField();
		userTextbox.setBounds(80, 35, 100, 20);
		
		
		//password set
		
		passLabel = new  JLabel("Password:");
		passLabel.setBounds(185, 35, 80, 20);
		
		passTextbox = new JPasswordField();
		passTextbox.setBounds(250, 35, 130, 20);
		
		// ctn set
		
		ctnLabel = new  JLabel("CTN :");
		ctnLabel.setBounds(10, 55, 70, 20);
		
		ctnTextbox = new JTextField();
		ctnTextbox.setBounds(80, 60, 100, 20);
		
		
		//button set
		activateButton = new JButton("activate");
		activateButton.setBounds(185, 60, 195, 20);
		
		
		
		activateButton.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
			            urlTextbox.setText("Welcome to Javatpoint.");  
			        }  
			    });  
		
		
		f.add(urlLabel);
		f.add(urlTextbox);
		f.add(activateButton);
		
		f.add(userLabel);
		f.add(userTextbox);
		f.add(passLabel);
		f.add(passTextbox);
		
		f.add(ctnLabel);
		f.add(ctnTextbox);
		
		f.setSize(400, 200);
		f.setLayout(null);
		
		f.setVisible(true);
	}

}
